data = [
    {
        'id': 0, 
        'status': "filled", 
        'batchInfo':{
            'batch': "qwe",
            'notes': "",
            'project': "qweqwe",
            'sampleId': 15,
            'seq_name': "C:\data_exports\seq_files\demoSeq.seq"
        },
        'color': "red"
    },
    {
        'id': 1, 
        'status': "filled", 
        'batchInfo':{
            'batch': "qwe",
            'notes': "",
            'project': "qweqwe",
            'sampleId': 15,
            'seq_name': "C:\data_exports\seq_files\demoSeq.seq"
        },
        'color': "red"
    },
    {
        'id': 2, 
        'status': "filled", 
        'batchInfo':{
            'batch': "qwe2",
            'notes': "",
            'project': "qweqwe2",
            'sampleId': 15,
            'seq_name': "C:\data_exports\seq_files\demoSeq.seq"
        },
        'color': "red"
    },
    {
        'id': 3, 
        'status': "filled", 
        'batchInfo':{
            'batch': "qwe2",
            'notes': "",
            'project': "qweqwe2",
            'sampleId': 15,
            'seq_name': "C:\data_exports\seq_files\demoSeq.seq"
        },
        'color': "red"
    },
    {
        'id': 4, 
        'status': "filled", 
        'batchInfo':{
            'batch': "qwe2",
            'notes': "",
            'project': "qweqwe2",
            'sampleId': 15,
            'seq_name': "C:\data_exports\seq_files\demoSeq.seq"
        },
        'color': "red"
    },
]

