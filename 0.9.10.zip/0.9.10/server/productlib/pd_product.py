class Product(object):
    def __init__(self, pd_name):
        self.name = pd_name
    
    def run_script(self, scriptName, data=None):
        return None